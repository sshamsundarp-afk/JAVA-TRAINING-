// Online Java Compiler (Editor)
// Write and run Java online using this editor.

public class Main {
    public static void main(String[] args) {
       int age=20;
        Boolean hashid=true;
        System.out.println("18!hashid");
    }
}
