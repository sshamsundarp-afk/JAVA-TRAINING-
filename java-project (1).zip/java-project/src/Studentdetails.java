// Online Java Compiler (Editor)
// Write and run Java online using this editor.

public class Studentdetails {
    public static void main(String[] args) {
int a=20;
        int b=30;
        int c=40;
        int sum=a+b+c;
        System.out.println("sum="+sum);
        System.out.println("Average="+sum/3);
    }
}
