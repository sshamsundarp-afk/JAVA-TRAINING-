// Online Java Compiler (Editor)
// Write and run Java online using this editor.

class Main {
    public static void main(String[] args) {
       int a=10;
        int b=5;
        System.out.println("modulus="+(a%b));
    }
}
