// Online Java Compiler (Editor)
// Write and run Java online using this editor.
     public class Unary {
public static void main(String[] args) {
   int a=10;
     System.out.println(a++);
     System.out.println(a--);
     System.out.println(++a);
    System.out.println(--a);
    }
}
