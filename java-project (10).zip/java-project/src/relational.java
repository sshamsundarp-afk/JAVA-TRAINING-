// Online Java Compiler (Editor)
// Write and run Java online using this editor.
public class relational{
public static void main(String[] args) {
    int a=85;
    int b=70;
     System.out.println(a>b);
     System.out.println(a<b);
     System.out.println(a>=b);
     System.out.println(a<=b);
     System.out.println(a!=b);
    System.out.println(a==b);
    }
}
