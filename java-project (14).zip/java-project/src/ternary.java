// Online Java Compiler (Editor)
// Write and run Java online using this editor.
 import java.util.Scanner;
public class ternary{
public static void main(String[] args) {
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter the age");
    int a=sc.nextInt();
     String result=((a>=18) ? "Eligible":"Not Eligible");
     System.out.println(result);
    }
}
