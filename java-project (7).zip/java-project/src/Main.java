// Online Java Compiler (Editor)
// Write and run Java online using this editor.

class Main {
    public static void main(String[] args) {
       int age=20;
        Boolean hashid=true;
        System.out.println(age>=18&&hashid);
    }
}
