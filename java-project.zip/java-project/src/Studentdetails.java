// Online Java Compiler (Editor)
// Write and run Java online using this editor.

public class Studentdetails {
    public static void main(String[] args) {
String name="sham";
int age=20;
float mark=80.f;
char grade='A';
boolean passed=true;
System.out.println(name);
System.out.println(age);
System.out.println(mark);
System.out.println(grade);
System.out.println(passed);
    }
}
