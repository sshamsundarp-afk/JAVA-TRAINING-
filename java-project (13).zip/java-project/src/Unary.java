// Online Java Compiler (Editor)
// Write and run Java online using this editor.
     public class Unary {
public static void main(String[] args) {
   int a=3;
    int b=7;
     System.out.println(a+b*3);
     System.out.println((a+b)*3);
     System.out.println(++a);
    System.out.println(--a);
    }
}
